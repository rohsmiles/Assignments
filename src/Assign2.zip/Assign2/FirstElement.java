package Assign2;

import java.util.LinkedList;

public class FirstElement {
	public static void main(String[] args) {
		LinkedList<String> al=new LinkedList<>();
			al.add("Raj");
			al.add("Raja");
			al.add("Raju");
			al.add("Rajan");
			al.add("Rajshekar");
			System.out.println(al.get(0));
			
	}

}
