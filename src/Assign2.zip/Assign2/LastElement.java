package Assign2;

import java.util.LinkedList;

public class LastElement {
	public static void main(String[] args) {
		LinkedList<String> al=new LinkedList<>();
			al.add("Raj");
			al.add("Raja");
			al.add("Raju");
			al.add("Rajan");
			al.add("Rajshekar");
			System.out.println(al.get(al.size()-1));
			
	}

}
